﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Pharmacy_Information_System_CRUD_Mini_Project
{
    public partial class medFrm : Form
    {
        public medFrm()
        {
            InitializeComponent();
            CustomizeDataGridView();
        }

        private void dashboard_Load(object sender, EventArgs e)
        {
            string connection = "server=localhost;user id=root;password=;database=medicineinv_db;";


            string query2 = "select * from medicines";
            MySqlConnection conn = new MySqlConnection(connection);
            MySqlCommand cmd2 = new MySqlCommand(query2, conn);
            MySqlDataAdapter da = new MySqlDataAdapter();
            da.SelectCommand = cmd2;
            DataTable dt = new DataTable();
            da.Fill(dt);
            dgmedicine.DataSource = dt;





        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connection = "server=localhost;user id=root;password=;database=medicineinv_db;";
            string query = "INSERT INTO medicines (medicineid, medicinename, dosageform, medicinestrength, quantity, expirydate, manufacturer) " +
                           "VALUES ('" + this.txtmedicineid.Text.Replace("'", "''") + "','" +
                                     this.txtmedicinename.Text.Replace("'", "''") + "','" +
                                     this.txtdosageform.Text.Replace("'", "''") + "','" +
                                     this.txtmedicinestrength.Text.Replace("'", "''") + "','" +
                                     this.txtquantity.Text.Replace("'", "''") + "','" +
                                     this.txtexpirydate.Text.Replace("'", "''") + "','" +
                                     this.txtmanufacturer.Text.Replace("'", "''") + "')";

            MySqlConnection conn = new MySqlConnection( connection );
            MySqlCommand cmd = new MySqlCommand( query, conn );
            MySqlDataReader dr;
            conn.Open();
            dr = cmd.ExecuteReader();
            MessageBox.Show("Successfully Added!");
            conn.Close();

            string query2 = "select * from medicines";
            MySqlCommand cmd2 = new MySqlCommand( query2, conn );
            MySqlDataAdapter da = new MySqlDataAdapter();
            da.SelectCommand = cmd2;
            DataTable dt = new DataTable();
            da.Fill( dt );
            dgmedicine.DataSource = dt;


            RefreshDataGrid();




        }

        private void dgmedicine_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            string connection = "server=localhost;user id=root;password=;database=medicineinv_db;";
            string query = "UPDATE medicines SET " +
                           "medicineid = '" + this.txtmedicineid.Text.Replace("'", "''") + "', " +
                           "medicinename = '" + this.txtmedicinename.Text.Replace("'", "''") + "', " +
                           "dosageform = '" + this.txtdosageform.Text.Replace("'", "''") + "', " +
                           "medicinestrength = '" + this.txtmedicinestrength.Text.Replace("'", "''") + "', " +
                           "quantity = '" + this.txtquantity.Text.Replace("'", "''") + "', " +
                           "expirydate = '" + this.txtexpirydate.Text.Replace("'", "''") + "', " +
                           "manufacturer = '" + this.txtmanufacturer.Text.Replace("'", "''") + "' " +
                           "WHERE medicineid = '" + this.txtmedicineid.Text.Replace("'", "''") + "'";

            MySqlConnection conn = new MySqlConnection( connection );
            MySqlCommand cmd = new MySqlCommand( query, conn );
            MySqlDataReader dr;
            conn.Open();
            dr = cmd.ExecuteReader();

            MessageBox.Show("Updated Successfully!");
            conn.Close();

            string query2 = "select * from medicines";
            MySqlCommand cmd2 = new MySqlCommand( query2, conn );
            MySqlDataAdapter da = new MySqlDataAdapter();
            da.SelectCommand = cmd2;
            DataTable dt = new DataTable();
            da.Fill( dt );
            dgmedicine.DataSource = dt;

            RefreshDataGrid();





        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            string connection = "server=localhost;user id=root;password=;database=medicineinv_db;";
            string query = "Delete from medicines WHERE medicineid = '" + this.txtmedicineid.Text + "'";
            MySqlConnection conn = new MySqlConnection(connection);
            MySqlCommand cmd = new MySqlCommand(query, conn );
            MySqlDataReader dr;
            conn.Open() ;
            dr = cmd.ExecuteReader();
            MessageBox.Show("Deleted Successfully!");
            conn.Close();
            string query2 = "select * from medicines";
            MySqlCommand cmd2 = new MySqlCommand( query2, conn );
            MySqlDataAdapter da = new MySqlDataAdapter();
            da.SelectCommand = cmd2;
            DataTable dt = new DataTable();
            da.Fill( dt );
            dgmedicine.DataSource = dt;

            RefreshDataGrid();

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtmedicineid.Text = "";
            txtmedicinename.Text = "";
            txtdosageform.Text = "";
            txtmedicinestrength.Text = "";
            txtquantity.Text = "";
            txtexpirydate.Text = "";
            txtmanufacturer.Text = "";

        }

        private void RefreshDataGrid()
        {
            string connection = "server=localhost;user id=root;password=;database=medicineinv_db;";
            string query2 = "select * from medicines";
            MySqlConnection conn = new MySqlConnection(connection);
            MySqlCommand cmd2 = new MySqlCommand(query2, conn);
            MySqlDataAdapter da = new MySqlDataAdapter();
            da.SelectCommand = cmd2;
            DataTable dt = new DataTable();
            da.Fill(dt);
            dgmedicine.DataSource = dt;
        }


        private void CustomizeDataGridView()
        {
            dgmedicine.DefaultCellStyle.ForeColor = Color.Black;
            dgmedicine.DefaultCellStyle.SelectionForeColor = Color.White;
        }

        private void txtmedicinestrength_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
